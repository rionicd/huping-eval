import express from 'express';
import cors from 'cors';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5050;
const DB_DIR = process.env.DATA_DIR || __dirname;
const DB_FILE = path.join(DB_DIR, 'db.json');

app.use(cors());
app.use(express.json());

let writeQueue = Promise.resolve();

// 初始化数据库
async function initDb() {
  try {
    await fs.mkdir(DB_DIR, { recursive: true });
    await fs.access(DB_FILE);
  } catch {
    const defaultData = {
      config: {
        adminPassword: "admin",
        minScore: 85,
        maxScore: 99
      },
      teachers: [],
      submissions: [] // 匿名提交记录
    };
    await fs.writeFile(DB_FILE, JSON.stringify(defaultData, null, 2), 'utf-8');
  }
}

// 从本地物理文件读取
async function readLocalDb() {
  await initDb();
  const data = await fs.readFile(DB_FILE, 'utf-8');
  return JSON.parse(data);
}

// 读取数据库（支持公网 KV 数据库与本地物理文件双备份）
async function readDb() {
  const bucket = process.env.KVDB_BUCKET;
  if (bucket) {
    try {
      const res = await fetch(`https://kvdb.io/${bucket}/db`);
      if (res.status === 200) {
        const text = await res.text();
        return JSON.parse(text);
      } else if (res.status === 404) {
        // 云端无数据，使用本地 db.json 初始化种子数据并同步到云端
        console.log("KVdb key not found. Initializing with local db.json...");
        const localData = await readLocalDb();
        await writeDb(localData);
        return localData;
      }
    } catch (err) {
      console.error("读取云端 KVdb 失败，降级读取本地文件:", err);
    }
  }
  return readLocalDb();
}

// 写入数据库
async function writeDb(data) {
  const bucket = process.env.KVDB_BUCKET;
  if (bucket) {
    return new Promise((resolve, reject) => {
      writeQueue = writeQueue.then(async () => {
        try {
          const res = await fetch(`https://kvdb.io/${bucket}/db`, {
            method: 'POST',
            body: JSON.stringify(data)
          });
          if (res.ok) {
            resolve();
          } else {
            reject(new Error(`KVdb 写入失败，状态码: ${res.status}`));
          }
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  return new Promise((resolve, reject) => {
    writeQueue = writeQueue.then(async () => {
      try {
        await fs.writeFile(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
        resolve();
      } catch (err) {
        reject(err);
      }
    });
  });
}

// 初始化
await initDb();

// ================= API 路由 =================

// 1. 获取教师列表
app.get('/api/teachers', async (req, res) => {
  try {
    const db = await readDb();
    res.json(db.teachers);
  } catch (error) {
    res.status(500).json({ message: "获取教师列表失败", error: error.message });
  }
});

// 2. 匿名提交整卷测评打分 (带校验，不全或有错误直接全卷作废)
app.post('/api/submissions', async (req, res) => {
  const { role, scores } = req.body;
  
  if (!role || !["校级干部", "中层干部", "教师"].includes(role)) {
    return res.status(400).json({ message: "无效的评议人身份" });
  }

  if (!scores || typeof scores !== 'object') {
    return res.status(400).json({ message: "无效的打分数据" });
  }

  try {
    const db = await readDb();
    const teachers = db.teachers;
    const { minScore = 85, maxScore = 99 } = db.config || {};

    // 根据评议人身份决定期望被评分教师列表
    let expectedTeachers = [];
    if (role === "教师") {
      expectedTeachers = teachers; // 普通教师评议全员 30 人
    } else if (role === "校级干部") {
      expectedTeachers = teachers.filter(t => t.type !== "校级干部"); // 校级干部评中层和普通教师 20 人
    } else if (role === "中层干部") {
      expectedTeachers = teachers.filter(t => t.type !== "中层干部"); // 中层干部评校级和普通教师 20 人
    }

    const submittedIds = Object.keys(scores);
    const expectedIds = expectedTeachers.map(t => t.id);

    // 校验1：打分完整性与匹配性
    const isComplete = expectedIds.length > 0 && 
                       expectedIds.every(id => submittedIds.includes(id)) && 
                       submittedIds.length === expectedIds.length;

    if (!isComplete) {
      return res.status(400).json({ message: "打分不全或提交了无关范围教师的评分！整卷已作废。" });
    }

    // 校验2：打分范围有效性（所有人分数都必须在 85 到 99 之间）
    for (const teacherId of expectedIds) {
      const val = parseInt(scores[teacherId], 10);
      if (isNaN(val) || val < minScore || val > maxScore) {
        return res.status(400).json({ 
          message: `打分值错误！分数必须在 ${minScore}-${maxScore} 分之间，整卷已作废。` 
        });
      }
    }

    // 通过全部校验后，保存本次有效提交
    const newSubmission = {
      id: `s_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
      role,
      scores
    };

    db.submissions.push(newSubmission);
    await writeDb(db);

    res.json({ success: true, submissionId: newSubmission.id });
  } catch (error) {
    res.status(500).json({ message: "提交测评失败", error: error.message });
  }
});

// 3. 管理员密码验证
app.post('/api/admin/verify', async (req, res) => {
  const { password } = req.body;
  try {
    const db = await readDb();
    if (db.config.adminPassword === password) {
      res.json({ success: true });
    } else {
      res.status(401).json({ success: false, message: "密码错误" });
    }
  } catch (error) {
    res.status(500).json({ message: "服务器错误", error: error.message });
  }
});

// 4. 管理员获取当前回收统计进度
app.get('/api/admin/progress', async (req, res) => {
  try {
    const db = await readDb();
    res.json({
      totalSubmissions: db.submissions.length,
      totalTeachers: db.teachers.length
    });
  } catch (error) {
    res.status(500).json({ message: "获取进度失败", error: error.message });
  }
});

// 5. 管理员导入教师名单 (覆盖导入)
app.post('/api/admin/teachers/import', async (req, res) => {
  const { teachers } = req.body; // Array: [{ name, type }]
  if (!Array.isArray(teachers)) {
    return res.status(400).json({ message: "名单格式不正确" });
  }

  try {
    const db = await readDb();
    
    // 生成带 ID 的教师列表
    const newTeachers = teachers.map((t, idx) => ({
      id: `t_${Date.now()}_${idx}_${Math.random().toString(36).substr(2, 5)}`,
      name: t.name.trim(),
      type: t.type.trim() // "校级干部" | "中层干部" | "普通教师"
    }));

    db.teachers = newTeachers;
    db.submissions = []; // 每次导入新名单，自动清空打分数据

    await writeDb(db);
    res.json({ success: true, count: newTeachers.length });
  } catch (error) {
    res.status(500).json({ message: "导入名单失败", error: error.message });
  }
});

// 6. 管理员重置评分数据 (保留名单，清空答卷)
app.post('/api/admin/reset', async (req, res) => {
  try {
    const db = await readDb();
    db.submissions = [];
    await writeDb(db);
    res.json({ success: true, message: "所有已交打分卷已清空" });
  } catch (error) {
    res.status(500).json({ message: "重置数据失败", error: error.message });
  }
});

// 6.5. 管理员获取教师名单导入 CSV 模板
app.get('/api/admin/template', (req, res) => {
  try {
    const csvContent = "\ufeff姓名,身份类型\n陈校长,校级干部\n李主任,中层干部\n张老师,普通教师\n";
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent('教师名单导入模板')}.csv"`);
    res.status(200).send(csvContent);
  } catch (error) {
    res.status(500).json({ message: "获取模板失败", error: error.message });
  }
});

// 辅助函数：将数字转换为中文（用于生成 一号打分、二号打分 等列名）
function toChineseNum(num) {
  const changeNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  if (num <= 9) return changeNum[num];
  if (num === 10) return '十';
  if (num < 20) return '十' + changeNum[num % 10];
  let str = '';
  let k = Math.floor(num / 10);
  let g = num % 10;
  str += changeNum[k] + '十';
  if (g !== 0) str += changeNum[g];
  return str;
}

// 7. 导出明细与统计表接口
app.get('/api/admin/export/:type', async (req, res) => {
  const { type } = req.params; // "校级干部" | "中层干部" | "普通教师"
  
  if (!["校级干部", "中层干部", "普通教师"].includes(type)) {
    return res.status(400).json({ message: "未知的表格类型" });
  }

  try {
    const db = await readDb();
    const targetTeachers = db.teachers.filter(t => t.type === type);
    const submissions = db.submissions;

    // 统计表名
    let title = "";
    if (type === "校级干部") title = "校级干部民主评议明细统计表";
    else if (type === "中层干部") title = "中层干部民主评议明细统计表";
    else title = "教师测评明细统计表";

    // 筛选出针对该类型教师有打分数据的有效答卷
    const targetSubmissions = submissions.filter(sub => 
      targetTeachers.some(t => sub.scores[t.id] !== undefined && sub.scores[t.id] !== null)
    );
    const m = targetSubmissions.length; // 实际打分人数

    // 拼装 CSV 头部
    let csvContent = `\ufeff${title}\n`; // UTF-8 BOM 保证 Excel 不乱码
    
    let headers = ["序号", "被评教师姓名"];
    for (let i = 1; i <= m; i++) {
      headers.push(`${toChineseNum(i)}号打分`);
    }
    headers.push("平均得分", "最高分", "最低分");
    csvContent += headers.join(",") + "\n";

    // 逐个教师统计明细与汇总
    targetTeachers.forEach((teacher, idx) => {
      const row = [idx + 1, teacher.name];
      const scoreList = [];

      // 提取每份答卷上针对该教师的打分
      targetSubmissions.forEach(sub => {
        const val = sub.scores[teacher.id];
        if (val !== undefined && val !== null) {
          const numVal = Number(val);
          row.push(numVal);
          scoreList.push(numVal);
        } else {
          row.push(""); // 没有评分填空
        }
      });

      // 计算平均分、最高分、最低分
      let avg = "0.00";
      let max = 0;
      let min = 0;

      if (scoreList.length > 0) {
        const sum = scoreList.reduce((acc, curr) => acc + curr, 0);
        avg = (sum / scoreList.length).toFixed(2);
        max = Math.max(...scoreList);
        min = Math.min(...scoreList);
        row.push(avg, max, min);
      } else {
        row.push("0.00", "", "");
      }

      csvContent += row.join(",") + "\n";
    });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(title)}.csv"`);
    res.status(200).send(csvContent);

  } catch (error) {
    res.status(500).json({ message: "导出 CSV 报表失败", error: error.message });
  }
});

// ================= 托管前端静态文件 =================

const distPath = path.join(__dirname, 'dist');
app.use(express.static(distPath));

app.get('*', (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`[Server] 服务已启动，运行在端口 ${PORT}`);
});
